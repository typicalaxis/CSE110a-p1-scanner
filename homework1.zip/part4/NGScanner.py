import re
from functools import reduce
from time import time
import argparse
import pdb
import sys
sys.path.append("../part2/")
from tokens import tokens

# No line number this time
class ScannerException(Exception):
    pass

class NGScanner:
    def __init__(self, tokens):
        self.tokens = tokens

    def input_string(self, input_string):
        self.istring = input_string

    def token(self):
        # Loop until we find a token we can
        # return (or until the string is empty)
        while True:
            if len(self.istring) == 0:
                return None
            SINGLE_RE = ""
            # Check each token
            for t in tokens:
                SINGLE_RE = SINGLE_RE + "(?P<" + t[0] + ">" + t[1] + ")|"
            SINGLE_RE = SINGLE_RE[:-1]  #used https://geekflare.com/python-remove-last-character/ for help

            match = re.match(SINGLE_RE,self.istring)
            #match = [m for m in match if m[1] is not None]

            if match:
                gdict = match.groupdict()
                lexeme = ("","")
                for m in gdict:
                    if gdict[m] != None:
                        lexeme = (m,gdict[m])
                
                
                # figure how much we need to chop from our input string
                chop = len(lexeme[1])
                self.istring = self.istring[chop:]

                # if we did not match an IGNORE token, then we can
                # return the lexeme
                if lexeme[0] != "IGNORE":
                    return lexeme
            else:
                return None
if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument('file_name', type=str)
    parser.add_argument('--verbose', '-v', action='store_true')
    args = parser.parse_args()
    
    f = open(args.file_name)    
    f_contents = f.read()
    f.close()

    verbose = args.verbose

    s = NGScanner(tokens)
    s.input_string(f_contents)

    start = time()
    while True:
        t = s.token()
        if t is None:
            break
        if (verbose):
            print(t)
    end = time()
    print("time to parse (seconds): ",str(end-start))    
