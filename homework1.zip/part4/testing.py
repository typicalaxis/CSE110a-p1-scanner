import re
from functools import reduce
from time import time
import argparse
import pdb
import sys
sys.path.append("../part2/")
from tokens import tokens
SINGLE_RE = ""

for t in tokens:
    SINGLE_RE = SINGLE_RE + "(?P<" + t[0] + ">" + t[1] + ")|\n"
SINGLE_RE = SINGLE_RE[:-2]  #used https://geekflare.com/python-remove-last-character/ for help
print(SINGLE_RE)