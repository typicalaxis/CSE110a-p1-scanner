import re
from functools import reduce
from time import time
import argparse
import pdb
import sys
sys.path.append("../part2/")
from tokens import tokens

# No line number this time
class ScannerException(Exception):
    pass

class SOSScanner:
    def __init__(self, tokens):
        self.tokens = tokens

    def input_string(self, input_string):
        self.istring = input_string

    def token(self):
        while True:
            if len(self.istring) == 0:
                return None
            matches = []
            for t in tokens:
                matches.append((t[0],re.match(t[1], self.istring),t[2]))
           
            matches = [m for m in matches if m[1] is not None]
            if len(matches) == 0:
                raise ScannerException();
            longest = matches[0]
            lexeme = longest[2]((longest[0],longest[1][0]))
            for m in matches:
                Newlexeme = m[2]((m[0],m[1][0]))
                if(len(lexeme[1]) <  len(Newlexeme[1])):
                    lexeme = Newlexeme 

            chop = len(lexeme[1])
            self.istring = self.istring[chop:]

            if lexeme[0] != "IGNORE":
                return lexeme

if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument('file_name', type=str)
    parser.add_argument('--verbose', '-v', action='store_true')
    args = parser.parse_args()
    
    f = open(args.file_name)    
    f_contents = f.read()
    f.close()

    verbose = args.verbose

    s = SOSScanner(tokens)
    s.input_string(f_contents)

    start = time()
    while True:
        t = s.token()
        if t is None:
            break
        if (verbose):
            print(t)
    end = time()
    print("time to parse (seconds): ",str(end-start))    
