
#from asyncio.windows_events import NULL
#from gettext import NullTranslations

#from numpy import result_type


def idy(t):
    return t
    
def ididy(t):
    if(t[1] == "if"):
        return("IF","if")
    elif(t[1] == "else"):
        return("ELSE","else")
    elif(t[1] == "while"):
        return("WHILE","while")
    elif(t[1] == "int"):
        return("INT","int")
    elif(t[1] == "float"):
        return("FLOAT","float")
    else:
        return t

tokens = [
    ("ID",     "[a-zA-Z][a-zA-Z0-9]*", ididy),
    ("NUM",    "[0-9]*?(.)[0-9]+", idy),
    ("IGNORE", " |\n",   idy),
    ("HNUM", "0x[a-fA-F0-9]+",   idy),
    ("INCR", "\+\+",   idy),
    ("PLUS", "\+",   idy),
    ("MULT", "\*",   idy),
    ("SEMI", ";",   idy),
    ("LPARAN", "\(",   idy),
    ("RPARAN", "\)",   idy),
    ("LBRACE", "{",   idy),
    ("RBRACE", "}",   idy),
    ("ASSIGN", "\=",   idy),
    ]
